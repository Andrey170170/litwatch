#!/usr/bin/env python3
"""Export consistent catalog/acquisition snapshots for selective Restic backup.

Payloads stay on HDD. Each database uses SQLite's online backup API; the two
snapshots are individually consistent, not one cross-database transaction.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
from datetime import datetime, timezone

ARCHIVE = Path('/srv/arxiv-archive')
WORK = Path('/srv/arxiv-work')
DESTINATION = Path('/srv/backups/arxiv-catalog')



def require_mount(path: Path, expected: str) -> None:
    result = subprocess.run(['findmnt', '-rn', '-M', str(path), '-o', 'SOURCE'],
                            text=True, capture_output=True, check=True)
    if result.stdout.strip() != expected:
        raise RuntimeError(f'Wrong mounted source at {path}; expected {expected}')


def snapshot_database(source: Path, destination: Path) -> None:
    """Copy a live WAL database without touching its original journal mode."""
    if source.is_symlink() or not source.is_file():
        raise RuntimeError(f'Missing or unsafe database: {source}')
    with contextlib.closing(sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)) as incoming:
        with contextlib.closing(sqlite3.connect(destination)) as outgoing:
            incoming.backup(outgoing, pages=1024)
    with destination.open('rb') as saved:
        os.fsync(saved.fileno())


def export(work: Path, repo: Path, destination: Path) -> dict:
    """Prepare snapshots before refreshing stable exported paths under a lock."""
    if destination.is_symlink():
        raise RuntimeError(f'Unsafe backup destination: {destination}')
    destination.mkdir(parents=True, exist_ok=True)
    with (destination / '.export.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        # Incomplete exports are outside the selected backup path.
        with tempfile.TemporaryDirectory(prefix='.arxiv-export-', dir=destination.parent) as temporary:
            staging = Path(temporary)
            sources = {'catalog.sqlite': work / 'catalog/catalog.sqlite',
                       'progress.sqlite': work / 'state/progress.sqlite'}
            required = sum(p.stat().st_size for p in sources.values()) + 256 * 1024**2
            if shutil.disk_usage(destination).free < required:
                raise RuntimeError('Insufficient backup storage for fresh database snapshots')
            for name, source in sources.items():
                snapshot_database(source, staging / name)
            shutil.copytree(repo / 'manifests', staging / 'manifests')
            for pattern in ('*.md', 'SHA256SUMS*', 'requirements.lock', 'pyproject.toml'):
                for source in repo.glob(pattern):
                    if source.is_file() and not source.is_symlink():
                        shutil.copy2(source, staging / source.name)
            receipt = work / 'state/job.json'
            if receipt.is_file():
                shutil.copy2(receipt, staging / 'acquisition-job.json')
            report = {'created_at': datetime.now(timezone.utc).isoformat(),
                      'databases': {name: str(path) for name, path in sources.items()},
                      'restore': 'Stop the paper service; restore catalog.sqlite to catalog/catalog.sqlite and progress.sqlite to state/progress.sqlite. Restore source and HF payload directories from the selective snapshot. Bulk PDFs are intentionally absent.'}
            (staging / 'export.json').write_text(json.dumps(report, indent=2) + '\n')
            # Stable paths let Restic reuse unchanged files. The backup invocation
            # holds the same lock while reading so it never sees partial refresh.
            for source in staging.iterdir():
                target = destination / source.name
                if source.is_dir():
                    if target.exists():
                        shutil.rmtree(target)
                    shutil.move(str(source), target)
                else:
                    os.replace(source, target)
            descriptor = os.open(destination, os.O_DIRECTORY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-storage', action='store_true')
    parser.add_argument('--project', type=Path, required=True, help='Project checkout containing manifests and plans')
    args = parser.parse_args()
    for path, source in ((WORK, 'tank/arxiv-work'), (ARCHIVE, 'bulk/arxiv-archive'),
                         (DESTINATION.parent, 'tank/backups')):
        require_mount(path, source)
    for source in (WORK / 'catalog/catalog.sqlite', WORK / 'state/progress.sqlite', args.project / 'manifests'):
        if not source.exists():
            raise RuntimeError(f'Required backup source missing: {source}')
    if args.check_storage:
        print('Paper catalog backup mounts and sources verified.')
    else:
        print(json.dumps(export(WORK, args.project, DESTINATION), sort_keys=True))


if __name__ == '__main__':
    main()
